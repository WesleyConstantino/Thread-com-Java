public class Calc extends Thread {

  private final int time;
  private final int[] numbers;
  private int currentTotal = 0;
  private int sum;

  public Calc(int[] numbers, int time) {

    this.numbers = numbers;
    this.time = time;

  }

  @Override
  public void run() {

    try {

      for (int i = 0; i < numbers.length; i++) {

        sum = currentTotal + numbers[i];
        System.out.printf("%s somar %d + %d = %d \n", getName(), currentTotal, numbers[i], sum);
        currentTotal = sum;
        Thread.sleep(time);

      }

      System.out.printf("TOTAL %s = %d \n", getName(), currentTotal);

    } catch (InterruptedException e) {

      e.printStackTrace();

    }

  }

}