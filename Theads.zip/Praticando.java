public class Praticando {

  public static void main(String[] args) {

    int[] numbers = new int[100];
    int count = 0;

    for (int i : numbers) {
      numbers[count] = ++count;
    }

    Calc thread_0 = new Calc(numbers, 100);
    thread_0.start();

    Calc thread_1 = new Calc(numbers, 35);
    thread_1.start();

  }

}
